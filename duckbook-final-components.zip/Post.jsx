import styles from './Post.module.css';

export default function Post({ id, author, content, timestamp, likes, onLike, onRemove, isNew }) {
  return (
    <div
      className={styles.post}
      style={isNew ? { backgroundColor: '#e0ffe0' } : {}}
    >
      <p><strong>{author}</strong> <span className={styles.time}>{timestamp}</span></p>
      <p>{content}</p>
      <div className={styles.actions}>
        <button onClick={() => onLike(id)}>❤️ {likes}</button>
        <button onClick={() => onRemove(id)}>🗑️ Delete</button>
      </div>
    </div>
  );
}