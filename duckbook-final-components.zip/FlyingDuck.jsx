import { useEffect, useState } from 'react';

export default function FlyingDuck() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(true);
    const timer = setTimeout(() => setVisible(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  return visible ? (
    <div style={{
      position: 'fixed',
      top: '40%',
      left: 0,
      fontSize: '2rem',
      animation: 'fly 2s linear forwards',
      zIndex: 1000
    }}>
      🦆
    </div>
  ) : null;
}