export default function ActionButton({ onClick, children, color = '#007bff' }) {
  return (
    <button
      onClick={onClick}
      style={{
        backgroundColor: color,
        color: 'white',
        border: 'none',
        padding: '0.5rem 1rem',
        margin: '0.5rem',
        borderRadius: '6px',
        cursor: 'pointer',
        fontSize: '1rem'
      }}
    >
      {children}
    </button>
  );
}