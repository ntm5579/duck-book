import { useState } from 'react';

export default function PostForm({ onPost }) {
  const [author, setAuthor] = useState('');
  const [content, setContent] = useState('');

  function handleSubmit(e) {
    e.preventDefault();
    if (author.trim() && content.trim()) {
      onPost({ author, content });
      setAuthor('');
      setContent('');
    }
  }

  return (
    <form onSubmit={handleSubmit} style={{ margin: '1rem 0' }}>
      <input
        placeholder="Your name"
        value={author}
        onChange={e => setAuthor(e.target.value)}
        style={{ display: 'block', width: '100%', marginBottom: '0.5rem' }}
      />
      <textarea
        placeholder="What's on your mind?"
        value={content}
        onChange={e => setContent(e.target.value)}
        style={{ display: 'block', width: '100%', marginBottom: '0.5rem' }}
      />
      <button type="submit">Post</button>
    </form>
  );
}