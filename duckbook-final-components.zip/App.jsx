import { useState, useEffect } from 'react';
import Post from './Post';
import PostForm from './PostForm';
import ActionButton from './ActionButton';
import FlyingDuck from './FlyingDuck';
import './App.css';

export default function App() {
  const [posts, setPosts] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [darkMode, setDarkMode] = useState(() => {
    const stored = localStorage.getItem('duckbook-darkmode');
    return stored === 'true';
  });
  const [showDuck, setShowDuck] = useState(false);

  useEffect(() => {
    const storedPosts = localStorage.getItem('duckbook-posts');
    if (storedPosts) {
      setPosts(JSON.parse(storedPosts));
    }
    const timer = setTimeout(() => setLoading(false), 1000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    localStorage.setItem('duckbook-posts', JSON.stringify(posts));
    if (posts.some(p => p.isNew)) {
      const timer = setTimeout(() => {
        setPosts(prev => prev.map(p => ({ ...p, isNew: false })));
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [posts]);

  useEffect(() => {
    localStorage.setItem('duckbook-darkmode', darkMode.toString());
  }, [darkMode]);

  function addPost(newPost) {
    const timestamp = new Date().toISOString();
    const newEntry = {
      id: Date.now(),
      timestamp,
      likes: 0,
      isNew: true,
      ...newPost,
    };
    setPosts([newEntry, ...posts]);
    setShowDuck(true);
    setTimeout(() => setShowDuck(false), 2000);
  }

  function removePost(id) {
    setPosts(posts.filter(post => post.id !== id));
  }

  function addLikeToPost(id) {
    setPosts(
      posts.map(post =>
        post.id === id ? { ...post, likes: post.likes + 1 } : post
      )
    );
  }

  function toggleDarkMode() {
    setDarkMode(prev => !prev);
  }

  function clearAllPosts() {
    const confirmClear = window.confirm('Are you sure you want to delete all posts?');
    if (confirmClear) {
      setPosts([]);
    }
  }

  const sortedPosts = posts.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

  if (loading) {
    return <div className="loading">🌀 Loading Duckbook...</div>;
  }

  return (
    <div className={`wrapper ${darkMode ? 'dark' : 'light'}`}>
      {showDuck && <FlyingDuck />}
      <h1>🦆 Duckbook</h1>
      <ActionButton onClick={() => setShowForm(!showForm)}>
        {showForm ? 'Cancel' : 'Write a Post'}
      </ActionButton>
      <ActionButton onClick={clearAllPosts} color="#9e9e9e">🧹 Clear All Posts</ActionButton>
      <ActionButton onClick={toggleDarkMode}>
        {darkMode ? '🌞 Light Mode' : '🌙 Dark Mode'}
      </ActionButton>
      {showForm && <PostForm onPost={addPost} />}
      {sortedPosts.length === 0 ? (
        <p className="empty">No posts yet. Be the first to quack!</p>
      ) : (
        sortedPosts.map(post => (
          <Post
            key={post.id}
            {...post}
            timestamp={new Date(post.timestamp).toLocaleString()}
            onLike={addLikeToPost}
            onRemove={removePost}
          />
        ))
      )}
    </div>
  );
}